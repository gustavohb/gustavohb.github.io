using System.Collections.Generic;
using System.Linq;
using Godot;
using Godot.Collections;


public partial class DlcManager : Node
{
    public static DlcManager Instance { get; private set; }

    [Signal]
    public delegate void InitializationCompletedEventHandler();
    
    public Godot.Collections.Dictionary<string, string> DlcDirectories = new(){
        {"dlc_default", "res://dlcs/default"},
        {"dlc_corgi",   "res://dlcs/corgi"},
        {"dlc_kitty",   "res://dlcs/kitty"},
        {"dlc_sheepy",  "res://dlcs/sheepy"}
    };

    private string _dlcMainDirectory = "dlcs";

    public string _projectDirectory = ProjectSettings.GlobalizePath("res://");

    public List<string> DlcsPaths = new();
    private Array<string> _dlcsContentPaths = new();
    private Godot.Collections.Dictionary<string, Variant> _dlcContentDB = new();
    private Godot.Collections.Dictionary<string, Background> _dlcContentDBBackgrounds = new();
    private Godot.Collections.Dictionary<string, PackedScene> _dlcContentDBScenes = new();
    
    private static DlcManager _instance;

    public static bool Initialized { get; private set; } = false;
    
    private DlcManager()
    {
        Instance = this;
    }

    public void Initalize()
    {
        GD.PrintRich($"[color=green][DlcManager] project directory: {_projectDirectory}");
        
        
        //FileManager.GetAllFiles(ref _dlcsPaths, _projectDirectory + _dlcMainDirectory);
    
        foreach (string path in DlcsPaths)
        {
            LoadDlcFromPckOrZip(path);
        }
    
        LoadDlcContentIntoDB();
    }
    

    private void LoadDlcFromPckOrZip(string path)
    {
        bool result = ProjectSettings.LoadResourcePack(path);
        GD.PrintRich($"[color={(result ? "green" : "red")}][DlcManager] loaded: {path} [{result}]");
    }

    private void LoadDlcContentIntoDB()
    {
        FileManager.GetAllFiles(ref _dlcsContentPaths, "res://" + _dlcMainDirectory);
        
        GD.PrintRich($"[color=orange][DlcManager] loaded: {_dlcsContentPaths.Count}");

        foreach (string path in _dlcsContentPaths)
        {
            string newPath = path.Replace(".remap", "").Replace(".import", "");
            _dlcContentDB[newPath] = GD.Load(newPath);
            GD.PrintRich($"[DlcManager] {path} content added to DB");

            if (newPath.Find("/background/") > -1 && newPath.Find(".tres") > -1)
            {
                var background = GD.Load<Background>(newPath);
                if (background != null)
                {
                    _dlcContentDBBackgrounds[newPath] = background;
                    GD.PrintRich($"[DlcManager] {path} content added to Background DB");
                }
            }
            
            if (newPath.Find("/scenes/") > -1)
            {
                var scene = GD.Load<PackedScene>(newPath);
                if (scene != null)
                {
                    _dlcContentDBScenes[newPath] = scene;
                    GD.PrintRich($"[DlcManager] {path} content added to Scenes DB");
                }
            }
        }
        
        Initialized = true;
        EmitSignal(SignalName.InitializationCompleted);
    }

    public PackedScene GeScene(string path)
    {
        return _dlcContentDBScenes[path];
    }

    public CompressedTexture2D GetBackground(string path)
    {
        return ((Background)_dlcContentDBBackgrounds[path]).Image;
    }

    public CompressedTexture2D GetBackgroundLast()
    {
        if (_dlcContentDBBackgrounds.Count > 0)
        {
            string lastDlcPath = _dlcContentDBBackgrounds.Keys.Last();
            return _dlcContentDBBackgrounds[lastDlcPath].Image;
        }

        return null;
    }
}
