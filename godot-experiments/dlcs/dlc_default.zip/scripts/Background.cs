using Godot;

[GlobalClass]
public partial class Background : Resource
{
    [Export] public string Name;
    [Export] public CompressedTexture2D Image;
}
